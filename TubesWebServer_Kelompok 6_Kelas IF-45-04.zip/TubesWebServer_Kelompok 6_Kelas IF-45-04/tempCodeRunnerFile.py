except IOError:
        #Send response message for file not found 
        connectionSocket.send('HTTP/1.1 404 Not Found\r\n\r\n'.encode())
        errorMessage = '<html><head></head><body><h1>404 Not Found</h1></body></html>\r\n'
        connectionSocket.send(errorMessage.encode())
        connectionSocket.send(b'\r\n\r\n')